CREATE TABLE Patients (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(20)
);

CREATE TABLE Doctors (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL,
    Specialty NVARCHAR(100)
);

CREATE TABLE Appointments (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    AppointmentDate DATETIME NOT NULL,
    
    DoctorId INT NOT NULL,
    PatientId INT NOT NULL,

    CONSTRAINT FK_Appointments_Doctors FOREIGN KEY (DoctorId)
        REFERENCES Doctors(Id) ON DELETE CASCADE,

    CONSTRAINT FK_Appointments_Patients FOREIGN KEY (PatientId)
        REFERENCES Patients(Id) ON DELETE CASCADE
);