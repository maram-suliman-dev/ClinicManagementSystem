﻿using System.ComponentModel.DataAnnotations;

namespace MaramWebApplication1.Model
{
    public class Patient
    {
        [Key]
        public int Id { get; set; }
        [Required, MaxLength(50)]
        public string Name { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;

    }
}
