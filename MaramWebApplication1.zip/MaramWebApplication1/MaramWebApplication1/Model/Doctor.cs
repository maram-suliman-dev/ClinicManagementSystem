﻿using System.ComponentModel.DataAnnotations;

namespace MaramWebApplication1.Model
{
    public class Doctor
    {
        [Key]
        public int Id { get; set; }

        [Required, MaxLength(50)]
        public string Name { get; set; }

        public string Specialty { get; set; }

        public List<Appointment> Appointments { get; set; }
    }
}
