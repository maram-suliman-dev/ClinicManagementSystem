﻿using System.ComponentModel.DataAnnotations;

namespace MaramWebApplication1.Model
{
    public class Appointment
    {
        [Key]
        public int Id { get; set; }
        [Required,MaxLength(50)]  
        public DateTime AppointmentDate { get; set; }

        public int PatientId { get; set; }
        public Patient Patient { get; set; }

        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }
    }
}
