﻿using Microsoft.EntityFrameworkCore;

namespace MaramWebApplication1.Model
{
    public class BookingContext :DbContext
    {

        public BookingContext(DbContextOptions<BookingContext> options) : base(options)
        {
        }
            public DbSet<Patient> Patients { get; set; }
            public DbSet<Doctor> Doctors { get; set; }
            public DbSet<Appointment> Appointments { get; set; }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
              
            }
        }
    }